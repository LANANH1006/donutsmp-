package com.donutlike;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.List;
import java.util.UUID;

public class AhHandler extends GenericContainerScreenHandler {
    private final SimpleInventory ahInv;
    private final UUID viewer;

    public static void open(ServerPlayerEntity p) {
        p.openHandledScreen(new SimpleNamedScreenHandlerFactory(
            (syncId, inv, player) -> new AhHandler(syncId, inv, new SimpleInventory(54), player.getUuid()),
            Text.literal("Auction House")));
    }

    public AhHandler(int syncId, PlayerInventory pinv, SimpleInventory inv, UUID viewer) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, pinv, inv, 6);
        this.ahInv = inv;
        this.viewer = viewer;
        refresh();
    }

    private void refresh() {
        for (int i = 0; i < 54; i++) {
            if (i < DonutLike.LISTINGS.size()) {
                DonutLike.Listing l = DonutLike.LISTINGS.get(i);
                boolean own = l.seller != null && l.seller.equals(viewer);
                ItemStack d = l.stack.copy();
                d.set(DataComponentTypes.LORE, new LoreComponent(List.of(
                    Text.literal("§eGiá: $" + DonutLike.fmt(l.price)),
                    Text.literal("§7Người bán: " + l.sellerName),
                    Text.literal(own ? "§cClick để huỷ bán" : "§aClick để mua"))));
                ahInv.setStack(i, d);
            } else {
                ahInv.setStack(i, ItemStack.EMPTY);
            }
        }
    }

    @Override
    public void onSlotClick(int slot, int button, SlotActionType type, PlayerEntity player) {
        if (slot >= 0 && slot < 54 && slot < DonutLike.LISTINGS.size()
                && type == SlotActionType.PICKUP && player instanceof ServerPlayerEntity sp) {
            DonutLike.Listing l = DonutLike.LISTINGS.get(slot);
            if (l.seller != null && l.seller.equals(sp.getUuid())) {
                DonutLike.LISTINGS.remove(l);
                sp.getInventory().offerOrDrop(l.stack);
                DonutLike.msg(sp, "§eĐã huỷ bán, vật phẩm đã trả lại.");
            } else if (DonutLike.bal(sp.getUuid()) < l.price) {
                DonutLike.msg(sp, "§cBạn không đủ tiền ($" + DonutLike.fmt(l.price) + ").");
            } else {
                DonutLike.LISTINGS.remove(l);
                DonutLike.add(sp.getUuid(), -l.price);
                if (l.seller != null) {
                    DonutLike.add(l.seller, l.price);
                    ServerPlayerEntity seller = sp.getServer().getPlayerManager().getPlayer(l.seller);
                    if (seller != null) DonutLike.msg(seller, "§a[AH] " + sp.getName().getString() + " đã mua "
                        + l.stack.getName().getString() + " với giá $" + DonutLike.fmt(l.price));
                }
                sp.getInventory().offerOrDrop(l.stack);
                DonutLike.msg(sp, "§aĐã mua " + l.stack.getName().getString() + " với giá $" + DonutLike.fmt(l.price));
            }
            refresh();
        }
        syncState(); // chan moi thao tac keo tha, chi cho phep click mua
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) { return ItemStack.EMPTY; }
}
