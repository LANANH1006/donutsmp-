package com.donutlike;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.*;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class ExtraCommands {

    static class Tpa {
        UUID from; boolean here; long expire;
        Tpa(UUID f, boolean h, long e) { from = f; here = h; expire = e; }
    }

    static final Map<UUID, Tpa> TPA = new HashMap<>();
    static final Map<UUID, Long> RTP_CD = new HashMap<>();
    static final Set<UUID> AFK = new HashSet<>();

    static void msg(ServerPlayerEntity p, String s) { DonutLike.msg(p, s); }

    static boolean blocked(ServerPlayerEntity p) {
        if (Duels.inDuel(p)) { msg(p, "§cKhông thể dùng lệnh này khi đang duel."); return true; }
        return false;
    }

    static void tp(ServerPlayerEntity p, ServerWorld w, double x, double y, double z) {
        p.teleport(w, x, y, z, Set.of(), p.getYaw(), p.getPitch(), true);
    }

    static void inc(Map<String, Integer> m, UUID id, int d) { m.merge(id.toString(), d, Integer::sum); }

    static void register(CommandDispatcher<ServerCommandSource> d) {

        // /rtp
        d.register(literal("rtp").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            if (blocked(p)) return 0;
            long now = DonutLike.tick;
            Long cd = RTP_CD.get(p.getUuid());
            if (cd != null && now < cd) { msg(p, "§cChờ " + ((cd - now) / 20) + " giây nữa."); return 0; }
            ServerWorld w = c.getSource().getServer().getOverworld();
            for (int i = 0; i < 15; i++) {
                int x = DonutLike.R.nextInt(10001) - 5000, z = DonutLike.R.nextInt(10001) - 5000;
                w.getChunk(x >> 4, z >> 4);
                int y = w.getTopY(Heightmap.Type.WORLD_SURFACE, x, z);
                if (w.getBlockState(new BlockPos(x, y - 1, z)).isLiquid()) continue;
                tp(p, w, x + 0.5, y, z + 0.5);
                RTP_CD.put(p.getUuid(), now + 20 * 30);
                msg(p, "§aĐã RTP tới " + x + " " + y + " " + z);
                return 1;
            }
            msg(p, "§cKhông tìm được chỗ hợp lệ, thử lại.");
            return 0;
        }));

        // homes
        d.register(literal("sethome").executes(c -> setHome(c.getSource().getPlayerOrThrow(), "home"))
            .then(argument("name", StringArgumentType.word()).executes(c ->
                setHome(c.getSource().getPlayerOrThrow(), StringArgumentType.getString(c, "name")))));
        d.register(literal("home").executes(c -> goHome(c.getSource().getPlayerOrThrow(), "home"))
            .then(argument("name", StringArgumentType.word()).executes(c ->
                goHome(c.getSource().getPlayerOrThrow(), StringArgumentType.getString(c, "name")))));
        d.register(literal("delhome")
            .then(argument("name", StringArgumentType.word()).executes(c -> {
                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                Map<String, DonutLike.Home> hs = DonutLike.save.homes.get(p.getUuid().toString());
                String n = StringArgumentType.getString(c, "name");
                if (hs == null || hs.remove(n) == null) { msg(p, "§cKhông có home tên " + n); return 0; }
                msg(p, "§aĐã xoá home " + n);
                return 1;
            })));
        d.register(literal("homes").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            Map<String, DonutLike.Home> hs = DonutLike.save.homes.get(p.getUuid().toString());
            msg(p, "§eHomes: §f" + (hs == null || hs.isEmpty() ? "(trống)" : String.join(", ", hs.keySet())));
            return 1;
        }));

        // tpa
        d.register(literal("tpa").then(argument("player", net.minecraft.command.argument.EntityArgumentType.player()).executes(c ->
            tpaReq(c.getSource().getPlayerOrThrow(), net.minecraft.command.argument.EntityArgumentType.getPlayer(c, "player"), false))));
        d.register(literal("tpahere").then(argument("player", net.minecraft.command.argument.EntityArgumentType.player()).executes(c ->
            tpaReq(c.getSource().getPlayerOrThrow(), net.minecraft.command.argument.EntityArgumentType.getPlayer(c, "player"), true))));
        d.register(literal("tpaccept").executes(c -> {
            ServerPlayerEntity me = c.getSource().getPlayerOrThrow();
            Tpa t = TPA.remove(me.getUuid());
            if (t == null || DonutLike.tick > t.expire) { msg(me, "§cKhông có yêu cầu tpa nào."); return 0; }
            ServerPlayerEntity from = c.getSource().getServer().getPlayerManager().getPlayer(t.from);
            if (from == null) { msg(me, "§cNgười gửi đã offline."); return 0; }
            ServerPlayerEntity mover = t.here ? me : from;
            ServerPlayerEntity dest = t.here ? from : me;
            if (blocked(mover)) return 0;
            mover.teleport((ServerWorld) dest.getWorld(), dest.getX(), dest.getY(), dest.getZ(), Set.of(), mover.getYaw(), mover.getPitch(), true);
            msg(me, "§aĐã chấp nhận.");
            msg(from, "§a" + me.getName().getString() + " đã chấp nhận.");
            return 1;
        }));
        d.register(literal("tpdeny").executes(c -> {
            ServerPlayerEntity me = c.getSource().getPlayerOrThrow();
            Tpa t = TPA.remove(me.getUuid());
            if (t == null) { msg(me, "§cKhông có yêu cầu nào."); return 0; }
            ServerPlayerEntity from = c.getSource().getServer().getPlayerManager().getPlayer(t.from);
            if (from != null) msg(from, "§c" + me.getName().getString() + " đã từ chối tpa.");
            msg(me, "§eĐã từ chối.");
            return 1;
        }));

        // /stats
        d.register(literal("stats").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            String id = p.getUuid().toString();
            long secs = DonutLike.save.playSecs.getOrDefault(id, 0L);
            msg(p, "§6=== Thống kê ===\n§eTiền: §a$" + DonutLike.fmt(DonutLike.bal(p.getUuid()))
                + "\n§eShards: §d" + DonutLike.save.shards.getOrDefault(id, 0)
                + "\n§eKills: §f" + DonutLike.save.kills.getOrDefault(id, 0) + " §eDeaths: §f" + DonutLike.save.deaths.getOrDefault(id, 0)
                + "\n§eDuel thắng/thua: §f" + DonutLike.save.duelWins.getOrDefault(id, 0) + "/" + DonutLike.save.duelLosses.getOrDefault(id, 0)
                + "\n§eThời gian chơi: §f" + (secs / 3600) + "h " + ((secs % 3600) / 60) + "m");
            return 1;
        }));

        // /shards
        d.register(literal("shards").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            msg(p, "§dShards: " + DonutLike.save.shards.getOrDefault(p.getUuid().toString(), 0) + " §7(+1 mỗi 5 phút online, thắng duel cũng được thưởng)");
            return 1;
        }));

        // /shop /trash /ec /craft
        d.register(literal("shop").executes(c -> { ShopHandler.open(c.getSource().getPlayerOrThrow()); return 1; }));
        d.register(literal("trash").executes(c -> {
            c.getSource().getPlayerOrThrow().openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, inv, pl) -> GenericContainerScreenHandler.createGeneric9x6(id, inv), Text.literal("Thùng rác")));
            return 1;
        }));
        d.register(literal("ec").executes(c -> {
            c.getSource().getPlayerOrThrow().openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, inv, pl) -> GenericContainerScreenHandler.createGeneric9x3(id, inv, pl.getEnderChestInventory()), Text.literal("Ender Chest")));
            return 1;
        }));
        d.register(literal("craft").executes(c -> {
            c.getSource().getPlayerOrThrow().openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (id, inv, pl) -> new CraftingScreenHandler(id, inv, ScreenHandlerContext.create(pl.getWorld(), pl.getBlockPos())) {
                    @Override public boolean canUse(PlayerEntity player) { return true; }
                }, Text.literal("Crafting")));
            return 1;
        }));

        // /worth /sellall
        d.register(literal("worth").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            ItemStack h = p.getMainHandStack();
            if (h.isEmpty()) { msg(p, "§cHãy cầm vật phẩm trên tay."); return 0; }
            msg(p, "§eGiá bán (/sellall): §a$" + DonutLike.fmt(DonutLike.value(h.getItem()) * h.getCount() * 0.6)
                + " §7| §eGiá mua (/shop): §a$" + DonutLike.fmt(DonutLike.value(h.getItem()) * 1.5) + "/cái");
            return 1;
        }));
        d.register(literal("sellall").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            double total = 0; int n = 0;
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (s.isEmpty()) continue;
                String id = net.minecraft.registry.Registries.ITEM.getId(s.getItem()).getPath();
                if (!DonutLike.PRICES.containsKey(id)) continue;
                total += DonutLike.PRICES.get(id) * s.getCount() * 0.6;
                n += s.getCount();
                p.getInventory().setStack(i, ItemStack.EMPTY);
            }
            if (n == 0) { msg(p, "§cKhông có món nào bán được cho server."); return 0; }
            DonutLike.add(p.getUuid(), total);
            msg(p, "§aĐã bán " + n + " vật phẩm, nhận $" + DonutLike.fmt(total));
            return 1;
        }));

        // /daily /kit
        d.register(literal("daily").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            String id = p.getUuid().toString();
            long now = System.currentTimeMillis();
            Long last = DonutLike.save.lastDaily.get(id);
            if (last != null && now - last < 86400000L) {
                long left = (86400000L - (now - last)) / 60000;
                msg(p, "§cĐã nhận rồi. Quay lại sau " + (left / 60) + "h " + (left % 60) + "m");
                return 0;
            }
            DonutLike.save.lastDaily.put(id, now);
            DonutLike.add(p.getUuid(), 500);
            inc(DonutLike.save.shards, p.getUuid(), 5);
            msg(p, "§aNhận thưởng hằng ngày: $500 + 5 shards!");
            return 1;
        }));
        d.register(literal("kit").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            String id = p.getUuid().toString();
            long now = System.currentTimeMillis();
            Long last = DonutLike.save.lastKit.get(id);
            if (last != null && now - last < 86400000L) { msg(p, "§cKit đã nhận, chờ đủ 24h."); return 0; }
            DonutLike.save.lastKit.put(id, now);
            p.getInventory().offerOrDrop(new ItemStack(Items.IRON_SWORD));
            p.getInventory().offerOrDrop(new ItemStack(Items.IRON_PICKAXE));
            p.getInventory().offerOrDrop(new ItemStack(Items.IRON_AXE));
            p.getInventory().offerOrDrop(new ItemStack(Items.COOKED_BEEF, 16));
            p.getInventory().offerOrDrop(new ItemStack(Items.TORCH, 16));
            msg(p, "§aĐã nhận kit khởi đầu!");
            return 1;
        }));

        // /afk
        d.register(literal("afk").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            boolean now = AFK.add(p.getUuid());
            if (!now) AFK.remove(p.getUuid());
            c.getSource().getServer().getPlayerManager().broadcast(
                Text.literal("§7" + p.getName().getString() + (now ? " đã AFK." : " không còn AFK.")), false);
            return 1;
        }));

        // /donuthelp
        d.register(literal("donuthelp").executes(c -> {
            c.getSource().sendFeedback(() -> Text.literal(
                "§6=== DonutLike ===\n§e/spawn /rtp /home /sethome /delhome /homes /tpa /tpahere /tpaccept /tpdeny\n"
                + "§e/bal /pay /baltop /killtop /shardtop /playtop /stats /shards /daily /kit /afk /sidebar\n"
                + "§e/sell <giá> /ah /order <item> <sl> <giá> /sellall /worth /shop\n"
                + "§e/trash /ec /craft\n§e/duel bot <noob|normal|pro|cpvp> [cược] | /duel custom ... | /duel leave"), false);
            return 1;
        }));
    }

    static int setHome(ServerPlayerEntity p, String name) {
        Map<String, DonutLike.Home> hs = DonutLike.save.homes.computeIfAbsent(p.getUuid().toString(), k -> new HashMap<>());
        if (!hs.containsKey(name) && hs.size() >= 3) { msg(p, "§cTối đa 3 home. Dùng /delhome để xoá bớt."); return 0; }
        DonutLike.Home h = new DonutLike.Home();
        h.x = p.getX(); h.y = p.getY(); h.z = p.getZ();
        h.dim = p.getWorld().getRegistryKey().getValue().toString();
        hs.put(name, h);
        msg(p, "§aĐã đặt home '" + name + "'.");
        return 1;
    }

    static int goHome(ServerPlayerEntity p, String name) {
        if (blocked(p)) return 0;
        Map<String, DonutLike.Home> hs = DonutLike.save.homes.get(p.getUuid().toString());
        DonutLike.Home h = hs == null ? null : hs.get(name);
        if (h == null) { msg(p, "§cKhông có home '" + name + "'. Dùng /sethome."); return 0; }
        MinecraftServer s = p.getServer();
        ServerWorld w = s.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(h.dim)));
        if (w == null) w = s.getOverworld();
        tp(p, w, h.x, h.y, h.z);
        msg(p, "§aĐã về home '" + name + "'.");
        return 1;
    }

    static int tpaReq(ServerPlayerEntity p, ServerPlayerEntity t, boolean here) {
        if (p == t) { msg(p, "§cKhông thể tpa chính mình."); return 0; }
        TPA.put(t.getUuid(), new Tpa(p.getUuid(), here, DonutLike.tick + 20 * 60));
        msg(p, "§aĐã gửi yêu cầu tới " + t.getName().getString());
        msg(t, "§e" + p.getName().getString() + (here ? " muốn bạn dịch chuyển tới họ. " : " muốn dịch chuyển tới bạn. ")
            + "§a/tpaccept §7hoặc §c/tpdeny §7(60 giây)");
        return 1;
    }

    // goi moi giay: ten, thoi gian choi, shards
    static void everySecond(MinecraftServer s) {
        for (ServerPlayerEntity p : s.getPlayerManager().getPlayerList()) {
            String id = p.getUuid().toString();
            DonutLike.save.names.put(id, p.getName().getString());
            DonutLike.save.bal.putIfAbsent(id, DonutLike.START_MONEY);
            long secs = DonutLike.save.playSecs.merge(id, 1L, Long::sum);
            if (secs % 300 == 0) {
                inc(DonutLike.save.shards, p.getUuid(), 1);
                msg(p, "§d+1 shard (online 5 phút)");
            }
        }
    }
}
